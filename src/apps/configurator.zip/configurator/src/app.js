
import '../../collector/src/components/pane-layout.js';
import './components/configurator-header.js';
import './components/configurator-section-nav.js';
import './components/configurator-section-browser.js';
import './components/configurator-inspector.js';
import { configuratorShellStyles } from './css/shell.css.js';

const DOMAIN_LABELS = {
  manufacturer: 'Manufacturer',
  products: 'Products',
  materials: 'Materials',
  export: 'Export',
};

const SOURCE_DOMAIN_IDS = ['manufacturer', 'products', 'materials'];

const SECTION_LABELS = {
  overview: 'Overview',
  info: 'Info',
  packages: 'Packages',
  products: 'Products',
  globalSettings: 'Global Settings',
  settings: 'Settings',
  defaults: 'Defaults',
  configurations: 'Configurations',
  blocks: 'Blocks',
  connectorTypes: 'Connector Types',
  connectionTypes: 'Connection Types',
  blockCategoryTypes: 'Block Category Types',
  blockCategories: 'Block Categories',
  categories: 'Categories',
  meshes: 'Meshes',
  gltfs: 'GLTFs',
  loadingBases: 'Loading Bases',
  materials: 'Materials',
  textures: 'Textures',
  images: 'Images',
  materialCategories: 'Material Categories',
  materialCategoryTypes: 'Material Category Types',
  materialSets: 'Material Sets',
  themes: 'Themes',
};

const DOMAIN_SECTION_ORDER = {
  manufacturer: ['info', 'packages', 'products', 'globalSettings', 'settings', 'defaults'],
  products: [
    'configurations',
    'blocks',
    'connectorTypes',
    'connectionTypes',
    'blockCategoryTypes',
    'blockCategories',
    'categories',
    'meshes',
    'gltfs',
    'loadingBases',
    'settings',
    'defaults',
  ],
  materials: [
    'materials',
    'textures',
    'images',
    'materialCategories',
    'materialCategoryTypes',
    'materialSets',
    'settings',
    'defaults',
    'themes',
  ],
};

const DEFAULT_CARD_SECTIONS = new Set(['products:blocks']);

const RELATION_FIELD_TARGETS = {
  categoryId: 'categories',
  categoryIds: 'categories',
  blockCategoryTypeId: 'blockCategoryTypes',
  blockCategoryTypeIds: 'blockCategoryTypes',
  blockCategoryId: 'blockCategories',
  blockCategoryIds: 'blockCategories',
  meshId: 'meshes',
  meshIds: 'meshes',
  materialId: 'materials',
  materialIds: 'materials',
  textureId: 'textures',
  textureIds: 'textures',
  imageId: 'images',
  imageIds: 'images',
  gltfId: 'gltfs',
  gltfIds: 'gltfs',
  loadingBaseId: 'loadingBases',
  loadingBaseIds: 'loadingBases',
  connectorTypeId: 'connectorTypes',
  connectorTypeIds: 'connectorTypes',
  connectionTypeId: 'connectionTypes',
  connectionTypeIds: 'connectionTypes',
  blockId: 'blocks',
  blockIds: 'blocks',
  configurationId: 'configurations',
  configurationIds: 'configurations',
  materialSetId: 'materialSets',
  materialSetIds: 'materialSets',
  packageId: 'packages',
  packageIds: 'packages',
  productId: 'products',
  productIds: 'products',
};

const DEFAULT_SOURCE_FILE_NAMES = {
  manufacturer: 'manufacturer_info.json',
  products: 'index.json',
  materials: 'settings.json',
};

function normalizeKey(value) {
  return String(value || '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

function cloneJson(value) {
  if (typeof structuredClone === 'function') {
    return structuredClone(value);
  }
  return JSON.parse(JSON.stringify(value));
}

function slugify(value, fallback = 'entry') {
  const slug = String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64);
  return slug || fallback;
}

function isPlainObject(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function isEditableSection(value) {
  return Array.isArray(value) || isPlainObject(value);
}

function createEmptyValidation() {
  return {
    overviewWarnings: [],
    sections: {},
  };
}

function createEmptySourceState() {
  return {
    fileHandle: null,
    fileName: '',
    data: null,
    dirty: false,
    validation: createEmptyValidation(),
  };
}

function friendlyLabelFromKey(key, domainId = '') {
  const direct = SECTION_LABELS[key];
  if (direct) {
    return direct;
  }
  const normalized = normalizeKey(key);
  for (const [knownKey, label] of Object.entries(SECTION_LABELS)) {
    if (normalizeKey(knownKey) === normalized) {
      return label;
    }
  }
  if (domainId && normalized === normalizeKey(domainId)) {
    return DOMAIN_LABELS[domainId] || key;
  }
  return String(key || '')
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/\b\w/g, (match) => match.toUpperCase());
}

function ensureUniqueEntryId(sectionEntries, candidateId) {
  const base = slugify(candidateId || 'entry', 'entry');
  const existing = new Set(
    (Array.isArray(sectionEntries) ? sectionEntries : [])
      .map((entry) => String(entry?.id || '').trim())
      .filter(Boolean),
  );
  if (!existing.has(base)) {
    return base;
  }
  let index = 2;
  while (existing.has(`${base}-${index}`)) {
    index += 1;
  }
  return `${base}-${index}`;
}
function createDomainTemplate(domainId) {
  if (domainId === 'manufacturer') {
    return {
      id: '',
      title: '',
      description: '',
      version: '1.0.0',
      info: {},
      packages: [],
      products: [],
      globalSettings: {},
      settings: {},
    };
  }
  if (domainId === 'products') {
    return {
      id: '',
      title: '',
      description: '',
      version: '1.0.0',
      configurations: [],
      blocks: [],
      connectorTypes: [],
      connectionTypes: [],
      blockCategoryTypes: [],
      blockCategories: [],
      categories: [],
      meshes: [],
      gltfs: [],
      loadingBases: [],
      settings: {},
    };
  }
  if (domainId === 'materials') {
    return {
      id: '',
      title: '',
      description: '',
      version: '1.0.0',
      materials: [],
      textures: [],
      images: [],
      materialCategories: [],
      materialCategoryTypes: [],
      materialSets: [],
      settings: {},
      defaults: {},
    };
  }
  return {};
}

function createEntryTemplate(domainId, sectionId, nextIndex) {
  const index = Number.isInteger(nextIndex) ? nextIndex + 1 : 1;
  if (sectionId === 'blocks') {
    return {
      id: `block-${index}`,
      title: 'New block',
      description: '',
      dimensions: { width: 1, height: 1, depth: 1 },
    };
  }
  if (sectionId === 'configurations') {
    return {
      id: `configuration-${index}`,
      title: 'New configuration',
      instances: [],
    };
  }
  if (sectionId === 'materials') {
    return { id: `material-${index}`, name: `Material ${index}` };
  }
  if (sectionId === 'textures') {
    return { id: `texture-${index}`, name: `Texture ${index}` };
  }
  if (sectionId === 'images') {
    return { id: `image-${index}`, name: `Image ${index}`, url: '' };
  }
  if (sectionId === 'meshes') {
    return { id: `mesh-${index}`, name: `Mesh ${index}` };
  }
  if (sectionId === 'gltfs') {
    return { id: `gltf-${index}`, name: `GLTF ${index}` };
  }
  if (sectionId === 'loadingBases') {
    return { id: `loading-base-${index}`, name: `Loading base ${index}` };
  }
  if (sectionId === 'connectorTypes') {
    return { id: `connector-type-${index}`, name: `Connector type ${index}` };
  }
  if (sectionId === 'connectionTypes') {
    return { id: `connection-type-${index}`, name: `Connection type ${index}` };
  }
  if (sectionId === 'categories' || sectionId === 'blockCategories' || sectionId === 'materialCategories') {
    return {
      id: `${slugify(sectionId, 'category')}-${index}`,
      name: `${friendlyLabelFromKey(sectionId, domainId)} ${index}`,
    };
  }
  if (sectionId === 'blockCategoryTypes' || sectionId === 'materialCategoryTypes') {
    return {
      id: `${slugify(sectionId, 'type')}-${index}`,
      name: `${friendlyLabelFromKey(sectionId, domainId)} ${index}`,
    };
  }
  if (sectionId === 'packages') {
    return { id: `package-${index}`, title: `Package ${index}` };
  }
  if (sectionId === 'products') {
    return { id: `product-${index}`, title: `Product ${index}` };
  }
  return {
    id: `${slugify(sectionId || domainId || 'entry', 'entry')}-${index}`,
    name: `New ${friendlyLabelFromKey(sectionId || 'entry', domainId)}`,
  };
}

function buildRelationOptionsFromObject(data) {
  const options = {};
  if (!isPlainObject(data)) {
    return options;
  }
  for (const [key, value] of Object.entries(data)) {
    if (!Array.isArray(value)) {
      continue;
    }
    options[key] = value
      .map((entry) => {
        if (!isPlainObject(entry)) {
          return null;
        }
        const id = String(entry.id || '').trim();
        if (!id) {
          return null;
        }
        const title = String(entry.title || entry.name || entry.label || '').trim();
        return {
          value: id,
          label: title ? `${id} - ${title}` : id,
        };
      })
      .filter(Boolean);
  }
  return options;
}

function mergeRelationOptions(target, source) {
  const merged = { ...target };
  for (const [key, value] of Object.entries(source || {})) {
    const existing = Array.isArray(merged[key]) ? merged[key] : [];
    const byId = new Map(existing.map((item) => [String(item.value), item]));
    for (const item of Array.isArray(value) ? value : []) {
      byId.set(String(item.value), item);
    }
    merged[key] = Array.from(byId.values()).sort((a, b) => String(a.label).localeCompare(String(b.label)));
  }
  return merged;
}

function buildWorkspaceRelationOptions(sources) {
  let options = {};
  for (const domainId of SOURCE_DOMAIN_IDS) {
    const sourceData = sources?.[domainId]?.data;
    options = mergeRelationOptions(options, buildRelationOptionsFromObject(sourceData));
  }
  return options;
}

function validateArraySections(data) {
  const sections = {};
  if (!isPlainObject(data)) {
    return sections;
  }
  for (const [sectionId, sectionValue] of Object.entries(data)) {
    if (!Array.isArray(sectionValue)) {
      continue;
    }
    const missingIds = [];
    const duplicateIds = [];
    const entryWarnings = {};
    const seen = new Map();
    sectionValue.forEach((entry, index) => {
      const warnings = [];
      if (!isPlainObject(entry)) {
        warnings.push('Entry should be an object.');
      }
      const id = isPlainObject(entry) ? String(entry.id || '').trim() : '';
      if (!id) {
        missingIds.push(index);
        warnings.push('Missing id.');
      } else if (seen.has(id)) {
        duplicateIds.push(id);
        warnings.push(`Duplicate id: ${id}`);
        const firstIndex = seen.get(id);
        entryWarnings[firstIndex] = [...(entryWarnings[firstIndex] || []), `Duplicate id: ${id}`];
      } else {
        seen.set(id, index);
      }
      if (warnings.length > 0) {
        entryWarnings[index] = [...(entryWarnings[index] || []), ...warnings];
      }
    });
    const uniqueDuplicates = Array.from(new Set(duplicateIds));
    sections[sectionId] = {
      missingIds,
      duplicateIds: uniqueDuplicates,
      entryWarnings,
      warningCount: missingIds.length + uniqueDuplicates.length,
    };
  }
  return sections;
}
function validateSourceData(domainId, data) {
  const result = createEmptyValidation();
  if (!isPlainObject(data)) {
    result.overviewWarnings.push(`${DOMAIN_LABELS[domainId]} source root must be an object.`);
    return result;
  }
  if (domainId === 'manufacturer') {
    if (!isPlainObject(data.info) && !isPlainObject(data.globalSettings) && !isPlainObject(data.settings)) {
      result.overviewWarnings.push('Manufacturer source has no info/settings object yet.');
    }
  }
  if (domainId === 'products') {
    if (!Array.isArray(data.blocks)) {
      result.overviewWarnings.push('Products source is missing blocks array.');
    }
    if (!Array.isArray(data.configurations)) {
      result.overviewWarnings.push('Products source is missing configurations array.');
    }
  }
  if (domainId === 'materials') {
    if (!Array.isArray(data.materials)) {
      result.overviewWarnings.push('Materials source is missing materials array.');
    }
    if (!Array.isArray(data.textures)) {
      result.overviewWarnings.push('Materials source is missing textures array.');
    }
  }
  result.sections = validateArraySections(data);
  return result;
}

function mergeAdditive(base, addon) {
  if (!isPlainObject(addon)) {
    return base;
  }
  const target = isPlainObject(base) ? base : {};
  for (const [key, value] of Object.entries(addon)) {
    if (!(key in target)) {
      target[key] = cloneJson(value);
      continue;
    }
    if (isPlainObject(target[key]) && isPlainObject(value)) {
      target[key] = mergeAdditive(target[key], value);
      continue;
    }
    if (Array.isArray(target[key]) && Array.isArray(value) && target[key].length === 0 && value.length > 0) {
      target[key] = cloneJson(value);
    }
  }
  return target;
}

function buildIdSets(data) {
  const map = new Map();
  if (!isPlainObject(data)) {
    return map;
  }
  for (const [sectionId, sectionValue] of Object.entries(data)) {
    if (!Array.isArray(sectionValue)) {
      continue;
    }
    const ids = new Set();
    for (const entry of sectionValue) {
      if (!isPlainObject(entry)) {
        continue;
      }
      const id = String(entry.id || '').trim();
      if (id) {
        ids.add(id);
      }
    }
    map.set(sectionId, ids);
  }
  return map;
}

function buildExportPackage(sources) {
  const manufacturer = sources?.manufacturer?.data;
  const products = sources?.products?.data;
  const materials = sources?.materials?.data;
  const warnings = [];
  if (!isPlainObject(manufacturer)) {
    warnings.push('Manufacturer source is missing.');
  }
  if (!isPlainObject(products)) {
    warnings.push('Products source is missing.');
  }
  if (!isPlainObject(materials)) {
    warnings.push('Materials source is missing.');
  }
  const base = isPlainObject(products) ? cloneJson(products) : {};
  const withManufacturer = isPlainObject(manufacturer) ? mergeAdditive(base, manufacturer) : base;
  const merged = isPlainObject(materials) ? mergeAdditive(withManufacturer, materials) : withManufacturer;
  return {
    packageData: merged,
    warnings,
  };
}

function validateExportPackage(packageData) {
  const warnings = [];
  if (!isPlainObject(packageData)) {
    warnings.push('Generated package root must be an object.');
    return warnings;
  }
  const sections = validateArraySections(packageData);
  for (const [sectionId, sectionValidation] of Object.entries(sections)) {
    if (sectionValidation.missingIds.length > 0) {
      warnings.push(`${friendlyLabelFromKey(sectionId)}: ${sectionValidation.missingIds.length} entries missing id.`);
    }
    if (sectionValidation.duplicateIds.length > 0) {
      warnings.push(`${friendlyLabelFromKey(sectionId)} duplicate ids: ${sectionValidation.duplicateIds.join(', ')}`);
    }
  }
  const idSets = buildIdSets(packageData);
  const relationIssues = [];
  for (const [sectionId, sectionValue] of Object.entries(packageData)) {
    if (!Array.isArray(sectionValue)) {
      continue;
    }
    sectionValue.forEach((entry, index) => {
      if (!isPlainObject(entry)) {
        return;
      }
      for (const [fieldName, targetSection] of Object.entries(RELATION_FIELD_TARGETS)) {
        if (!(fieldName in entry)) {
          continue;
        }
        const targetIds = idSets.get(targetSection);
        if (!targetIds || targetIds.size === 0) {
          continue;
        }
        const value = entry[fieldName];
        if (Array.isArray(value)) {
          for (const item of value) {
            const id = String(item || '').trim();
            if (id && !targetIds.has(id)) {
              relationIssues.push(`${sectionId}[${index}] ${fieldName} references missing ${targetSection} id '${id}'.`);
            }
          }
        } else {
          const id = String(value || '').trim();
          if (id && !targetIds.has(id)) {
            relationIssues.push(`${sectionId}[${index}] ${fieldName} references missing ${targetSection} id '${id}'.`);
          }
        }
      }
    });
  }
  const uniqueRelationIssues = Array.from(new Set(relationIssues)).slice(0, 120);
  return [...warnings, ...uniqueRelationIssues];
}
class OpenConfiguratorManagerElement extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.state = {
      sources: {
        manufacturer: createEmptySourceState(),
        products: createEmptySourceState(),
        materials: createEmptySourceState(),
      },
      generatedPackageData: null,
      exportWarnings: [],
      activeDomain: 'manufacturer',
      sections: [{ id: 'overview', label: 'Overview', kind: 'overview', count: null, warningCount: 0 }],
      selectedSectionId: 'overview',
      selectedEntryRef: null,
      viewModes: {},
      relationOptions: {},
      statusText: 'Open Manufacturer, Products, and Materials source files to begin.',
      pendingOpenTarget: null,
    };
  }

  connectedCallback() {
    this.render();
    this.cacheDom();
    this.bindEvents();
    this.recomputeDerivedState();
    this.refreshAll();
  }

  render() {
    this.shadowRoot.innerHTML = `
      <style>${configuratorShellStyles}</style>
      <div class="app-shell">
        <open-configurator-header id="configHeader"></open-configurator-header>
        <section class="workspace">
          <open-pane-layout id="paneLayout" inspector-placement="right">
            <div class="workspace-grid" slot="main">
              <open-configurator-section-nav id="sectionNav"></open-configurator-section-nav>
              <open-configurator-section-browser id="sectionBrowser"></open-configurator-section-browser>
            </div>
            <open-configurator-inspector id="inspector" slot="inspector"></open-configurator-inspector>
          </open-pane-layout>
        </section>
        <input id="openFileInput" type="file" accept=".json,application/json" hidden />
      </div>
    `;
  }

  cacheDom() {
    const root = this.shadowRoot;
    this.dom = {
      header: root.getElementById('configHeader'),
      sectionNav: root.getElementById('sectionNav'),
      sectionBrowser: root.getElementById('sectionBrowser'),
      inspector: root.getElementById('inspector'),
      openFileInput: root.getElementById('openFileInput'),
    };
  }

  bindEvents() {
    this.dom.header.addEventListener('new-workspace', () => {
      this.createNewWorkspace();
    });
    this.dom.header.addEventListener('new-domain', () => {
      this.createNewDomainTemplate(this.state.activeDomain);
    });
    this.dom.header.addEventListener('open-domain-file', async () => {
      await this.openDomainFile(this.state.activeDomain);
    });
    this.dom.header.addEventListener('save-domain-file', async () => {
      await this.saveDomainFile(this.state.activeDomain);
    });
    this.dom.header.addEventListener('save-domain-file-as', async () => {
      await this.saveDomainFileAs(this.state.activeDomain);
    });
    this.dom.header.addEventListener('open-legacy-package', async () => {
      await this.openLegacyPackage();
    });
    this.dom.header.addEventListener('generate-export', () => {
      this.generateExport({ silent: false });
    });
    this.dom.header.addEventListener('download-export', async () => {
      await this.downloadGeneratedExport();
    });

    this.dom.openFileInput.addEventListener('change', async (event) => {
      const file = event.target?.files?.[0] || null;
      if (!file) {
        return;
      }
      await this.handlePendingOpenFile(file);
      event.target.value = '';
    });

    this.dom.sectionNav.addEventListener('domain-select', (event) => {
      const domainId = event.detail?.domainId || 'manufacturer';
      this.selectDomain(domainId);
    });

    this.dom.sectionNav.addEventListener('section-select', (event) => {
      const sectionId = event.detail?.sectionId || 'overview';
      this.selectSection(sectionId);
    });

    this.dom.sectionBrowser.addEventListener('entry-select', (event) => {
      if (!this.isSourceDomain(this.state.activeDomain)) {
        return;
      }
      this.state.selectedEntryRef = event.detail?.entryRef || null;
      this.normalizeSelectionForCurrentSection();
      this.renderSectionBrowser();
      this.renderInspector();
    });

    this.dom.sectionBrowser.addEventListener('view-mode-change', (event) => {
      const section = this.currentSection();
      if (!section || section.kind !== 'array') {
        return;
      }
      const mode = event.detail?.mode === 'cards' ? 'cards' : 'rows';
      const key = `${this.state.activeDomain}:${section.id}`;
      this.state.viewModes = {
        ...this.state.viewModes,
        [key]: mode,
      };
      this.renderSectionBrowser();
    });

    this.dom.sectionBrowser.addEventListener('array-action', (event) => {
      const action = event.detail?.action || '';
      if (action) {
        this.applyArrayAction(action);
      }
    });

    this.dom.inspector.addEventListener('entry-change', (event) => {
      this.applyEntryChange(event.detail || {});
    });
  }

  setStatus(text) {
    const next = String(text || '').trim();
    if (next) {
      this.state.statusText = next;
      this.renderHeader();
    }
  }

  isSourceDomain(domainId) {
    return SOURCE_DOMAIN_IDS.includes(domainId);
  }

  sourceFor(domainId) {
    if (!this.isSourceDomain(domainId)) {
      return null;
    }
    return this.state.sources[domainId] || null;
  }

  currentSource() {
    return this.sourceFor(this.state.activeDomain);
  }

  currentSourceData() {
    return this.currentSource()?.data || null;
  }

  hasAnyUnsavedChanges() {
    return SOURCE_DOMAIN_IDS.some((domainId) => this.sourceFor(domainId)?.dirty);
  }

  ensureDiscardConfirmed() {
    if (!this.hasAnyUnsavedChanges()) {
      return true;
    }
    return window.confirm('You have unsaved source changes. Continue and discard them?');
  }

  ensureDomainDiscardConfirmed(domainId) {
    const source = this.sourceFor(domainId);
    if (!source || !source.dirty) {
      return true;
    }
    const label = DOMAIN_LABELS[domainId] || domainId;
    return window.confirm(`${label} has unsaved changes. Continue and discard them?`);
  }
  buildDomainOrderIndex(domainId) {
    const order = DOMAIN_SECTION_ORDER[domainId] || [];
    return new Map(order.map((key, index) => [normalizeKey(key), index]));
  }

  buildSectionsForDomain(domainId) {
    if (domainId === 'export') {
      const generated = this.state.generatedPackageData;
      const generatedCount = isPlainObject(generated) ? Object.keys(generated).length : 0;
      const warningCount = this.state.exportWarnings.length;
      return [
        { id: 'overview', label: 'Overview', kind: 'overview', count: null, warningCount },
        { id: 'exportPreview', label: 'Generated Package', kind: 'export', count: generatedCount, warningCount },
      ];
    }

    const source = this.sourceFor(domainId);
    const data = source?.data;
    const validation = source?.validation || createEmptyValidation();
    const sections = [{
      id: 'overview',
      label: 'Overview',
      kind: 'overview',
      count: null,
      warningCount: validation.overviewWarnings.length,
    }];

    if (!isPlainObject(data)) {
      return sections;
    }

    const orderIndex = this.buildDomainOrderIndex(domainId);
    const keys = Object.keys(data).filter((key) => isEditableSection(data[key]));
    keys.sort((a, b) => {
      const ai = orderIndex.has(normalizeKey(a)) ? orderIndex.get(normalizeKey(a)) : Number.MAX_SAFE_INTEGER;
      const bi = orderIndex.has(normalizeKey(b)) ? orderIndex.get(normalizeKey(b)) : Number.MAX_SAFE_INTEGER;
      if (ai !== bi) {
        return ai - bi;
      }
      return a.localeCompare(b);
    });

    for (const key of keys) {
      const value = data[key];
      const kind = Array.isArray(value) ? 'array' : 'object';
      const count = kind === 'array' ? value.length : Object.keys(value || {}).length;
      const warningCount = validation.sections?.[key]?.warningCount || 0;
      sections.push({
        id: key,
        label: friendlyLabelFromKey(key, domainId),
        kind,
        count,
        warningCount,
      });
    }

    return sections;
  }

  recomputeDerivedState() {
    for (const domainId of SOURCE_DOMAIN_IDS) {
      const source = this.sourceFor(domainId);
      source.validation = validateSourceData(domainId, source.data);
    }

    this.state.relationOptions = buildWorkspaceRelationOptions(this.state.sources);
    this.refreshGeneratedExportSnapshot();
    this.state.sections = this.buildSectionsForDomain(this.state.activeDomain);

    if (!this.state.sections.some((entry) => entry.id === this.state.selectedSectionId)) {
      this.state.selectedSectionId = this.state.sections[0]?.id || 'overview';
      this.state.selectedEntryRef = null;
    }

    this.normalizeSelectionForCurrentSection();
  }

  refreshGeneratedExportSnapshot() {
    const build = buildExportPackage(this.state.sources);
    this.state.generatedPackageData = build.packageData;
    this.state.exportWarnings = [
      ...build.warnings,
      ...validateExportPackage(build.packageData),
    ];
  }

  buildDomainsViewModel() {
    return [
      {
        id: 'manufacturer',
        label: 'Manufacturer',
        loaded: isPlainObject(this.sourceFor('manufacturer')?.data),
        dirty: Boolean(this.sourceFor('manufacturer')?.dirty),
      },
      {
        id: 'products',
        label: 'Products',
        loaded: isPlainObject(this.sourceFor('products')?.data),
        dirty: Boolean(this.sourceFor('products')?.dirty),
      },
      {
        id: 'materials',
        label: 'Materials',
        loaded: isPlainObject(this.sourceFor('materials')?.data),
        dirty: Boolean(this.sourceFor('materials')?.dirty),
      },
      {
        id: 'export',
        label: 'Export',
        loaded: isPlainObject(this.state.generatedPackageData) && Object.keys(this.state.generatedPackageData).length > 0,
        dirty: false,
      },
    ];
  }

  currentSection() {
    return this.state.sections.find((section) => section.id === this.state.selectedSectionId) || this.state.sections[0] || null;
  }

  currentSectionValue() {
    const section = this.currentSection();
    if (!section || section.id === 'overview') {
      return null;
    }
    if (this.state.activeDomain === 'export') {
      if (section.id === 'exportPreview') {
        return this.state.generatedPackageData;
      }
      return null;
    }
    return this.currentSourceData()?.[section.id];
  }

  normalizeSelectionForCurrentSection() {
    const section = this.currentSection();
    const value = this.currentSectionValue();

    if (!section || section.id === 'overview' || this.state.activeDomain === 'export') {
      this.state.selectedEntryRef = null;
      return;
    }

    if (section.kind === 'array') {
      const list = Array.isArray(value) ? value : [];
      if (list.length === 0) {
        this.state.selectedEntryRef = null;
        return;
      }
      const index = Number(this.state.selectedEntryRef?.index);
      if (!Number.isInteger(index) || index < 0 || index >= list.length) {
        this.state.selectedEntryRef = { index: 0 };
      }
      return;
    }

    if (section.kind === 'object') {
      const keys = isPlainObject(value) ? Object.keys(value) : [];
      if (keys.length === 0) {
        this.state.selectedEntryRef = { scope: 'section' };
        return;
      }
      const key = this.state.selectedEntryRef?.key;
      if (!key || !keys.includes(key)) {
        this.state.selectedEntryRef = { key: keys[0] };
      }
    }
  }
  selectedEntryValue() {
    const section = this.currentSection();
    const sectionValue = this.currentSectionValue();
    const ref = this.state.selectedEntryRef || {};

    if (!section || section.id === 'overview' || this.state.activeDomain === 'export') {
      return undefined;
    }

    if (section.kind === 'array') {
      if (!Array.isArray(sectionValue)) {
        return undefined;
      }
      return Number.isInteger(ref.index) ? sectionValue[ref.index] : undefined;
    }

    if (section.kind === 'object') {
      if (!isPlainObject(sectionValue)) {
        return undefined;
      }
      if (typeof ref.key === 'string' && ref.key in sectionValue) {
        return sectionValue[ref.key];
      }
      return ref.scope === 'section' ? sectionValue : undefined;
    }

    return undefined;
  }

  sectionViewMode(domainId, sectionId) {
    if (!domainId || !sectionId) {
      return 'rows';
    }
    const key = `${domainId}:${sectionId}`;
    const fromState = this.state.viewModes[key];
    if (fromState === 'cards' || fromState === 'rows') {
      return fromState;
    }
    return DEFAULT_CARD_SECTIONS.has(key) ? 'cards' : 'rows';
  }

  arrayActionState() {
    const section = this.currentSection();
    const value = this.currentSectionValue();
    const index = Number(this.state.selectedEntryRef?.index);
    const length = Array.isArray(value) ? value.length : 0;
    const hasSelection = Number.isInteger(index) && index >= 0 && index < length;
    const isEditableArray = this.isSourceDomain(this.state.activeDomain) && section?.kind === 'array';
    return {
      canAdd: isEditableArray,
      canDuplicate: isEditableArray && hasSelection,
      canDelete: isEditableArray && hasSelection,
      canMoveUp: isEditableArray && hasSelection && index > 0,
      canMoveDown: isEditableArray && hasSelection && index < length - 1,
    };
  }

  selectDomain(domainId) {
    if (!DOMAIN_LABELS[domainId]) {
      return;
    }
    this.state.activeDomain = domainId;
    this.state.selectedSectionId = 'overview';
    this.state.selectedEntryRef = null;
    this.recomputeDerivedState();
    this.renderSectionNav();
    this.renderSectionBrowser();
    this.renderInspector();
    this.renderHeader();
  }

  selectSection(sectionId) {
    this.state.selectedSectionId = sectionId;
    const section = this.currentSection();
    const value = this.currentSectionValue();

    if (!section || section.id === 'overview' || this.state.activeDomain === 'export') {
      this.state.selectedEntryRef = null;
    } else if (section.kind === 'array') {
      this.state.selectedEntryRef = Array.isArray(value) && value.length > 0 ? { index: 0 } : null;
    } else if (section.kind === 'object') {
      const keys = isPlainObject(value) ? Object.keys(value) : [];
      this.state.selectedEntryRef = keys.length > 0 ? { key: keys[0] } : { scope: 'section' };
    } else {
      this.state.selectedEntryRef = null;
    }

    this.renderSectionNav();
    this.renderSectionBrowser();
    this.renderInspector();
  }

  overviewStats() {
    if (this.state.activeDomain === 'export') {
      const manufacturer = this.sourceFor('manufacturer')?.data;
      const products = this.sourceFor('products')?.data;
      const materials = this.sourceFor('materials')?.data;
      const generated = this.state.generatedPackageData;
      return [
        { label: 'Manufacturer keys', count: isPlainObject(manufacturer) ? Object.keys(manufacturer).length : 0 },
        { label: 'Products keys', count: isPlainObject(products) ? Object.keys(products).length : 0 },
        { label: 'Materials keys', count: isPlainObject(materials) ? Object.keys(materials).length : 0 },
        { label: 'Generated keys', count: isPlainObject(generated) ? Object.keys(generated).length : 0 },
      ];
    }

    return this.state.sections
      .filter((section) => section.id !== 'overview')
      .map((section) => ({ label: section.label, count: section.count }));
  }

  sectionValidation(sectionId) {
    const source = this.currentSource();
    if (!source) {
      return null;
    }
    return source.validation?.sections?.[sectionId] || null;
  }

  selectedEntryWarnings() {
    if (!this.isSourceDomain(this.state.activeDomain)) {
      return [];
    }
    const section = this.currentSection();
    if (!section || section.id === 'overview') {
      return [];
    }
    const sectionValidation = this.sectionValidation(section.id);
    const ref = this.state.selectedEntryRef || {};
    if (section.kind === 'array' && Number.isInteger(ref.index)) {
      const map = sectionValidation?.entryWarnings || {};
      return Array.isArray(map[ref.index]) ? map[ref.index] : [];
    }
    return [];
  }

  exportSummaryStats() {
    const generated = this.state.generatedPackageData;
    if (!isPlainObject(generated)) {
      return [];
    }
    const stats = [];
    for (const [key, value] of Object.entries(generated)) {
      if (Array.isArray(value)) {
        stats.push({ label: friendlyLabelFromKey(key, 'export'), count: value.length });
      }
    }
    return stats.slice(0, 12);
  }
  renderHeader() {
    this.dom.header.setState({
      activeDomain: this.state.activeDomain,
      statusText: this.state.statusText,
      canDownloadExport: isPlainObject(this.state.generatedPackageData) && Object.keys(this.state.generatedPackageData).length > 0,
      domainStates: {
        manufacturer: {
          loaded: isPlainObject(this.sourceFor('manufacturer')?.data),
          dirty: Boolean(this.sourceFor('manufacturer')?.dirty),
          fileName: this.sourceFor('manufacturer')?.fileName || '',
        },
        products: {
          loaded: isPlainObject(this.sourceFor('products')?.data),
          dirty: Boolean(this.sourceFor('products')?.dirty),
          fileName: this.sourceFor('products')?.fileName || '',
        },
        materials: {
          loaded: isPlainObject(this.sourceFor('materials')?.data),
          dirty: Boolean(this.sourceFor('materials')?.dirty),
          fileName: this.sourceFor('materials')?.fileName || '',
        },
      },
    });
  }

  renderSectionNav() {
    this.dom.sectionNav.update({
      domains: this.buildDomainsViewModel(),
      activeDomainId: this.state.activeDomain,
      sections: this.state.sections,
      selectedSectionId: this.state.selectedSectionId,
    });
  }

  renderSectionBrowser() {
    const section = this.currentSection();
    const isExport = this.state.activeDomain === 'export';
    this.dom.sectionBrowser.update({
      section,
      sectionValue: this.currentSectionValue(),
      selectedEntryRef: isExport ? null : this.state.selectedEntryRef,
      overviewStats: this.overviewStats(),
      overviewWarnings: isExport
        ? this.state.exportWarnings
        : (this.currentSource()?.validation?.overviewWarnings || []),
      exportPayload: isExport
        ? {
            warnings: this.state.exportWarnings,
            summary: this.exportSummaryStats(),
            jsonText: JSON.stringify(this.state.generatedPackageData || {}, null, 2),
          }
        : null,
      viewMode: this.sectionViewMode(this.state.activeDomain, section?.id),
      sectionValidation: isExport || !section ? null : this.sectionValidation(section.id),
      arrayActions: this.arrayActionState(),
    });
  }

  renderInspector() {
    if (!this.isSourceDomain(this.state.activeDomain)) {
      this.dom.inspector.setData({
        section: null,
        entryRef: null,
        entryValue: undefined,
        relationOptions: this.state.relationOptions,
        relationFieldTargets: RELATION_FIELD_TARGETS,
        entryWarnings: [],
      });
      return;
    }

    this.dom.inspector.setData({
      section: this.currentSection(),
      entryRef: this.state.selectedEntryRef,
      entryValue: this.selectedEntryValue(),
      relationOptions: this.state.relationOptions,
      relationFieldTargets: RELATION_FIELD_TARGETS,
      entryWarnings: this.selectedEntryWarnings(),
    });
  }

  refreshAll() {
    this.renderHeader();
    this.renderSectionNav();
    this.renderSectionBrowser();
    this.renderInspector();
  }

  applyEntryChange(detail) {
    if (!this.isSourceDomain(this.state.activeDomain)) {
      return;
    }

    const section = this.currentSection();
    const source = this.currentSource();
    if (!section || !source || !isPlainObject(source.data) || section.id === 'overview') {
      return;
    }
    if (detail.sectionId !== section.id) {
      return;
    }

    const nextData = cloneJson(source.data);
    const ref = detail.entryRef || {};
    const value = detail.value;

    if (section.kind === 'array' && Number.isInteger(ref.index) && Array.isArray(nextData[section.id])) {
      nextData[section.id][ref.index] = value;
    } else if (section.kind === 'object' && isPlainObject(nextData[section.id])) {
      if (typeof ref.key === 'string') {
        nextData[section.id][ref.key] = value;
      } else if (ref.scope === 'section') {
        nextData[section.id] = value;
      }
    }

    source.data = nextData;
    source.dirty = true;
    this.recomputeDerivedState();
    this.setStatus(`Edited ${section.label} in ${DOMAIN_LABELS[this.state.activeDomain]}.`);
    this.renderSectionNav();
    this.renderSectionBrowser();
    this.renderInspector();
  }

  applyArrayAction(action) {
    if (!this.isSourceDomain(this.state.activeDomain)) {
      return;
    }

    const section = this.currentSection();
    const sectionId = section?.id || '';
    const source = this.currentSource();
    const entries = this.currentSectionValue();

    if (!section || section.kind !== 'array' || !Array.isArray(entries) || !source || !isPlainObject(source.data)) {
      return;
    }

    const index = Number(this.state.selectedEntryRef?.index);
    const hasSelection = Number.isInteger(index) && index >= 0 && index < entries.length;
    const nextData = cloneJson(source.data);
    const list = Array.isArray(nextData[sectionId]) ? nextData[sectionId] : [];
    let nextIndex = hasSelection ? index : -1;

    if (action === 'add') {
      const template = createEntryTemplate(this.state.activeDomain, sectionId, list.length);
      if (isPlainObject(template) && template.id) {
        template.id = ensureUniqueEntryId(list, template.id);
      }
      list.push(template);
      nextIndex = list.length - 1;
      this.state.statusText = `Added entry to ${section.label}.`;
    } else if (action === 'duplicate') {
      if (!hasSelection) {
        return;
      }
      const sourceEntry = cloneJson(list[index]);
      if (isPlainObject(sourceEntry) && sourceEntry.id) {
        sourceEntry.id = ensureUniqueEntryId(list, `${sourceEntry.id}-copy`);
      }
      list.splice(index + 1, 0, sourceEntry);
      nextIndex = index + 1;
      this.state.statusText = `Duplicated entry in ${section.label}.`;
    } else if (action === 'delete') {
      if (!hasSelection) {
        return;
      }
      const confirmDelete = window.confirm(`Delete selected entry from ${section.label}?`);
      if (!confirmDelete) {
        return;
      }
      list.splice(index, 1);
      nextIndex = Math.max(0, Math.min(index, list.length - 1));
      if (list.length === 0) {
        this.state.selectedEntryRef = null;
      }
      this.state.statusText = `Deleted entry from ${section.label}.`;
    } else if (action === 'move-up') {
      if (!hasSelection || index <= 0) {
        return;
      }
      const temp = list[index - 1];
      list[index - 1] = list[index];
      list[index] = temp;
      nextIndex = index - 1;
      this.state.statusText = `Moved entry up in ${section.label}.`;
    } else if (action === 'move-down') {
      if (!hasSelection || index >= list.length - 1) {
        return;
      }
      const temp = list[index + 1];
      list[index + 1] = list[index];
      list[index] = temp;
      nextIndex = index + 1;
      this.state.statusText = `Moved entry down in ${section.label}.`;
    } else {
      return;
    }

    nextData[sectionId] = list;
    source.data = nextData;
    source.dirty = true;
    this.recomputeDerivedState();

    if (list.length > 0 && Number.isInteger(nextIndex) && nextIndex >= 0) {
      this.state.selectedEntryRef = { index: nextIndex };
    }

    this.renderHeader();
    this.renderSectionNav();
    this.renderSectionBrowser();
    this.renderInspector();
  }
  createNewWorkspace() {
    if (!this.ensureDiscardConfirmed()) {
      return;
    }

    this.state.sources = {
      manufacturer: createEmptySourceState(),
      products: createEmptySourceState(),
      materials: createEmptySourceState(),
    };
    this.state.generatedPackageData = null;
    this.state.exportWarnings = [];
    this.state.activeDomain = 'manufacturer';
    this.state.selectedSectionId = 'overview';
    this.state.selectedEntryRef = null;
    this.state.viewModes = {};

    this.recomputeDerivedState();
    this.setStatus('Created a new workspace. Load or create source files for each domain.');
    this.refreshAll();
  }

  createNewDomainTemplate(domainId) {
    if (!this.isSourceDomain(domainId)) {
      return;
    }

    if (!this.ensureDomainDiscardConfirmed(domainId)) {
      return;
    }

    const source = this.sourceFor(domainId);
    source.data = createDomainTemplate(domainId);
    source.fileHandle = null;
    source.fileName = DEFAULT_SOURCE_FILE_NAMES[domainId] || `${domainId}.json`;
    source.dirty = true;

    this.state.activeDomain = domainId;
    this.state.selectedSectionId = 'overview';
    this.state.selectedEntryRef = null;

    this.recomputeDerivedState();
    this.setStatus(`Created new ${DOMAIN_LABELS[domainId]} source template.`);
    this.refreshAll();
  }

  async openDomainFile(domainId) {
    if (!this.isSourceDomain(domainId)) {
      return;
    }

    if (!this.ensureDomainDiscardConfirmed(domainId)) {
      return;
    }

    try {
      if (typeof window.showOpenFilePicker === 'function') {
        const [handle] = await window.showOpenFilePicker({
          multiple: false,
          excludeAcceptAllOption: false,
          types: [
            {
              description: 'JSON files',
              accept: {
                'application/json': ['.json'],
              },
            },
          ],
        });

        if (!handle) {
          return;
        }

        const file = await handle.getFile();
        await this.loadDomainFromFile(domainId, file, handle);
        return;
      }

      this.state.pendingOpenTarget = { mode: 'domain', domainId };
      this.dom.openFileInput.click();
    } catch (error) {
      if (error?.name === 'AbortError') {
        return;
      }
      this.setStatus(`Open failed: ${error.message}`);
    }
  }

  async openLegacyPackage() {
    try {
      if (!this.ensureDomainDiscardConfirmed('products')) {
        return;
      }

      if (typeof window.showOpenFilePicker === 'function') {
        const [handle] = await window.showOpenFilePicker({
          multiple: false,
          excludeAcceptAllOption: false,
          types: [
            {
              description: 'JSON files',
              accept: {
                'application/json': ['.json'],
              },
            },
          ],
        });

        if (!handle) {
          return;
        }

        const file = await handle.getFile();
        await this.loadLegacyPackageFromFile(file, handle);
        return;
      }

      this.state.pendingOpenTarget = { mode: 'legacy' };
      this.dom.openFileInput.click();
    } catch (error) {
      if (error?.name === 'AbortError') {
        return;
      }
      this.setStatus(`Open legacy package failed: ${error.message}`);
    }
  }

  async handlePendingOpenFile(file) {
    const pending = this.state.pendingOpenTarget;
    this.state.pendingOpenTarget = null;

    if (!pending || !file) {
      return;
    }

    if (pending.mode === 'domain' && pending.domainId) {
      await this.loadDomainFromFile(pending.domainId, file, null);
      return;
    }

    if (pending.mode === 'legacy') {
      await this.loadLegacyPackageFromFile(file, null);
    }
  }

  async loadDomainFromFile(domainId, file, handle) {
    if (!this.isSourceDomain(domainId)) {
      return;
    }

    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      if (!isPlainObject(parsed)) {
        throw new Error('Selected JSON must contain one top-level object.');
      }

      const source = this.sourceFor(domainId);
      source.data = parsed;
      source.fileHandle = handle || null;
      source.fileName = file.name || (handle?.name || DEFAULT_SOURCE_FILE_NAMES[domainId] || `${domainId}.json`);
      source.dirty = false;

      this.state.activeDomain = domainId;
      this.state.selectedSectionId = 'overview';
      this.state.selectedEntryRef = null;
      this.recomputeDerivedState();
      this.setStatus(`Opened ${DOMAIN_LABELS[domainId]} source ${source.fileName}.`);
      this.refreshAll();
    } catch (error) {
      this.setStatus(`Open ${DOMAIN_LABELS[domainId]} failed: ${error.message}`);
    }
  }

  async loadLegacyPackageFromFile(file, handle) {
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      if (!isPlainObject(parsed)) {
        throw new Error('Selected JSON must contain one top-level object.');
      }

      const source = this.sourceFor('products');
      source.data = parsed;
      source.fileHandle = handle || null;
      source.fileName = file.name || (handle?.name || DEFAULT_SOURCE_FILE_NAMES.products);
      source.dirty = false;

      this.state.activeDomain = 'products';
      this.state.selectedSectionId = 'overview';
      this.state.selectedEntryRef = null;
      this.recomputeDerivedState();
      this.setStatus(`Loaded legacy package into Products domain from ${source.fileName}.`);
      this.refreshAll();
    } catch (error) {
      this.setStatus(`Open legacy package failed: ${error.message}`);
    }
  }

  serializeSource(domainId) {
    const source = this.sourceFor(domainId);
    if (!source || !isPlainObject(source.data)) {
      throw new Error(`No ${DOMAIN_LABELS[domainId] || domainId} source is loaded.`);
    }
    return `${JSON.stringify(source.data, null, 2)}\n`;
  }

  serializeGeneratedPackage() {
    if (!isPlainObject(this.state.generatedPackageData)) {
      throw new Error('No generated package is available yet.');
    }
    return `${JSON.stringify(this.state.generatedPackageData, null, 2)}\n`;
  }

  async writeToHandle(handle, text) {
    const writable = await handle.createWritable();
    await writable.write(text);
    await writable.close();
  }

  downloadBlob(text, fileName) {
    const blob = new Blob([text], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName || 'configurator-export.json';
    link.click();
    URL.revokeObjectURL(url);
  }

  async saveDomainFile(domainId) {
    if (!this.isSourceDomain(domainId)) {
      return;
    }

    try {
      const source = this.sourceFor(domainId);
      const text = this.serializeSource(domainId);
      if (source.fileHandle && typeof source.fileHandle.createWritable === 'function') {
        await this.writeToHandle(source.fileHandle, text);
        source.dirty = false;
        this.setStatus(`Saved ${DOMAIN_LABELS[domainId]} source ${source.fileName}.`);
        this.renderHeader();
        this.renderSectionNav();
        return;
      }

      await this.saveDomainFileAs(domainId);
    } catch (error) {
      this.setStatus(`Save ${DOMAIN_LABELS[domainId]} failed: ${error.message}`);
    }
  }

  async saveDomainFileAs(domainId) {
    if (!this.isSourceDomain(domainId)) {
      return;
    }

    try {
      const source = this.sourceFor(domainId);
      const text = this.serializeSource(domainId);
      const suggestedName = source.fileName || DEFAULT_SOURCE_FILE_NAMES[domainId] || `${domainId}.json`;

      if (typeof window.showSaveFilePicker === 'function') {
        const handle = await window.showSaveFilePicker({
          suggestedName,
          types: [
            {
              description: 'JSON files',
              accept: {
                'application/json': ['.json'],
              },
            },
          ],
        });

        if (!handle) {
          return;
        }

        await this.writeToHandle(handle, text);
        source.fileHandle = handle;
        source.fileName = handle.name || suggestedName;
        source.dirty = false;
        this.setStatus(`Saved ${DOMAIN_LABELS[domainId]} source ${source.fileName}.`);
        this.renderHeader();
        this.renderSectionNav();
        return;
      }

      this.downloadBlob(text, suggestedName);
      source.dirty = false;
      source.fileName = suggestedName;
      this.setStatus(`Downloaded ${DOMAIN_LABELS[domainId]} source ${suggestedName}.`);
      this.renderHeader();
      this.renderSectionNav();
    } catch (error) {
      if (error?.name === 'AbortError') {
        return;
      }
      this.setStatus(`Save As ${DOMAIN_LABELS[domainId]} failed: ${error.message}`);
    }
  }

  generateExport(options = {}) {
    this.recomputeDerivedState();
    if (!options.silent) {
      const warningCount = this.state.exportWarnings.length;
      this.setStatus(warningCount > 0
        ? `Generated export with ${warningCount} warning${warningCount === 1 ? '' : 's'}.`
        : 'Generated export package from workspace sources.');
    }

    this.renderHeader();
    this.renderSectionNav();
    this.renderSectionBrowser();
    this.renderInspector();
  }

  async downloadGeneratedExport() {
    try {
      this.generateExport({ silent: true });
      const text = this.serializeGeneratedPackage();
      const suggestedName = 'configurator-package.json';

      if (typeof window.showSaveFilePicker === 'function') {
        const handle = await window.showSaveFilePicker({
          suggestedName,
          types: [
            {
              description: 'JSON files',
              accept: {
                'application/json': ['.json'],
              },
            },
          ],
        });

        if (!handle) {
          return;
        }

        await this.writeToHandle(handle, text);
        this.setStatus(`Export package saved as ${handle.name || suggestedName}.`);
        return;
      }

      this.downloadBlob(text, suggestedName);
      this.setStatus(`Export package downloaded as ${suggestedName}.`);
    } catch (error) {
      if (error?.name === 'AbortError') {
        return;
      }
      this.setStatus(`Export download failed: ${error.message}`);
    }
  }
}

if (!customElements.get('open-configurator-manager')) {
  customElements.define('open-configurator-manager', OpenConfiguratorManagerElement);
}

export { OpenConfiguratorManagerElement };
