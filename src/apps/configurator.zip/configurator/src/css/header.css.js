export const configuratorHeaderStyles = `
  :host {
    display: block;
  }

  * {
    box-sizing: border-box;
  }

  .topbar {
    background: #ffffff;
    border-bottom: 1px solid #dbe3ec;
    padding: 0.7rem 0.95rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.8rem;
  }

  .brand {
    min-width: 0;
    display: grid;
    gap: 0.12rem;
  }

  .title {
    margin: 0;
    font-size: 0.98rem;
    font-weight: 700;
    color: #0f172a;
  }

  .status {
    margin: 0;
    color: #64748b;
    font-size: 0.82rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: min(56vw, 620px);
  }

  .actions {
    display: flex;
    align-items: center;
    gap: 0.45rem;
    flex-wrap: wrap;
    justify-content: flex-end;
    max-width: 68%;
  }

  .btn {
    border: 1px solid #cbd5e1;
    background: #ffffff;
    color: #0f172a;
    border-radius: 8px;
    padding: 0.42rem 0.7rem;
    cursor: pointer;
    font: inherit;
    font-size: 0.84rem;
    font-weight: 600;
  }

  .btn:hover {
    background: #f8fafc;
  }

  .btn-primary {
    background: #0f6cc6;
    color: #ffffff;
    border-color: #0f6cc6;
  }

  .btn-primary:hover {
    background: #0d5eae;
  }

  .package-pill {
    border-radius: 999px;
    border: 1px solid #bfdbfe;
    background: #eff6ff;
    color: #1d4ed8;
    padding: 0.2rem 0.55rem;
    font-size: 0.75rem;
    font-weight: 700;
    max-width: 240px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .pill-neutral {
    border-color: #cbd5e1;
    background: #f8fafc;
    color: #334155;
  }

  @media (max-width: 760px) {
    .topbar {
      padding: 0.55rem 0.7rem;
      align-items: flex-start;
    }

    .actions {
      width: 100%;
      justify-content: flex-start;
      max-width: 100%;
    }

    .status {
      max-width: 90vw;
    }
  }
`;
