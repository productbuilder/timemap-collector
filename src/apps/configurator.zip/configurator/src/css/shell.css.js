export const configuratorShellStyles = `
  :host {
    display: block;
    color: #111827;
    font-family: "Segoe UI", Tahoma, sans-serif;
  }

  * {
    box-sizing: border-box;
  }

  .app-shell {
    height: min(100dvh, 100vh);
    min-height: 680px;
    background: #eef2f7;
    border: 1px solid #d9e0ea;
    border-radius: 10px;
    overflow: hidden;
    display: grid;
    grid-template-rows: auto minmax(0, 1fr);
  }

  .workspace {
    min-height: 0;
    display: block;
    overflow: hidden;
  }

  .workspace-grid {
    display: grid;
    grid-template-columns: 250px minmax(0, 1fr);
    min-height: 0;
    height: 100%;
    overflow: hidden;
    gap: 0;
  }

  open-configurator-section-nav {
    min-height: 0;
    border-right: 1px solid #dbe3ec;
    background: #f8fafc;
  }

  open-configurator-section-browser {
    min-height: 0;
    padding: 0.9rem;
    overflow: hidden;
  }

  open-configurator-inspector {
    min-height: 0;
    border-left: 1px solid #dbe3ec;
    background: #ffffff;
  }

  @media (max-width: 1080px) {
    .workspace-grid {
      grid-template-columns: minmax(0, 1fr);
      grid-template-rows: 220px minmax(0, 1fr);
    }

    open-configurator-section-nav {
      border-right: none;
      border-bottom: 1px solid #dbe3ec;
    }
  }

  @media (max-width: 760px) {
    .app-shell {
      border: none;
      border-radius: 0;
      min-height: 100dvh;
    }

    .workspace-grid {
      grid-template-rows: 190px minmax(0, 1fr);
    }

    open-configurator-section-browser {
      padding: 0.65rem;
    }
  }
`;
