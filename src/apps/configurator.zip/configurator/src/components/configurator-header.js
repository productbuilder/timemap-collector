import { configuratorHeaderStyles } from '../css/header.css.js';

const DOMAIN_LABELS = {
  manufacturer: 'Manufacturer',
  products: 'Products',
  materials: 'Materials',
  export: 'Export',
};

class OpenConfiguratorHeaderElement extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.model = {
      activeDomain: 'manufacturer',
      statusText: 'Open Manufacturer, Products, and Materials source files to begin.',
      canDownloadExport: false,
      domainStates: {
        manufacturer: { loaded: false, dirty: false, fileName: '' },
        products: { loaded: false, dirty: false, fileName: '' },
        materials: { loaded: false, dirty: false, fileName: '' },
      },
    };
  }

  connectedCallback() {
    this.render();
    this.bindEvents();
    this.applyModel();
  }

  bindEvents() {
    this.shadowRoot.getElementById('newWorkspaceBtn')?.addEventListener('click', () => {
      this.dispatch('new-workspace');
    });
    this.shadowRoot.getElementById('newDomainBtn')?.addEventListener('click', () => {
      this.dispatch('new-domain');
    });
    this.shadowRoot.getElementById('openDomainBtn')?.addEventListener('click', () => {
      this.dispatch('open-domain-file');
    });
    this.shadowRoot.getElementById('saveDomainBtn')?.addEventListener('click', () => {
      this.dispatch('save-domain-file');
    });
    this.shadowRoot.getElementById('saveDomainAsBtn')?.addEventListener('click', () => {
      this.dispatch('save-domain-file-as');
    });
    this.shadowRoot.getElementById('openLegacyBtn')?.addEventListener('click', () => {
      this.dispatch('open-legacy-package');
    });
    this.shadowRoot.getElementById('generateExportBtn')?.addEventListener('click', () => {
      this.dispatch('generate-export');
    });
    this.shadowRoot.getElementById('downloadExportBtn')?.addEventListener('click', () => {
      this.dispatch('download-export');
    });
  }

  dispatch(name, detail = {}) {
    this.dispatchEvent(new CustomEvent(name, { detail, bubbles: true, composed: true }));
  }

  setState(nextState = {}) {
    this.model = { ...this.model, ...nextState };
    this.applyModel();
  }

  applyModel() {
    const workspacePill = this.shadowRoot.getElementById('workspacePill');
    const domainPill = this.shadowRoot.getElementById('domainPill');
    const status = this.shadowRoot.getElementById('statusText');
    const newDomainBtn = this.shadowRoot.getElementById('newDomainBtn');
    const openDomainBtn = this.shadowRoot.getElementById('openDomainBtn');
    const saveDomainBtn = this.shadowRoot.getElementById('saveDomainBtn');
    const saveDomainAsBtn = this.shadowRoot.getElementById('saveDomainAsBtn');
    const downloadExportBtn = this.shadowRoot.getElementById('downloadExportBtn');
    if (!workspacePill || !domainPill || !status) {
      return;
    }

    const activeDomain = this.model.activeDomain || 'manufacturer';
    const activeDomainLabel = DOMAIN_LABELS[activeDomain] || 'Domain';
    const isSourceDomain = activeDomain !== 'export';

    const stateFor = (domainId) => this.model.domainStates?.[domainId] || { loaded: false, dirty: false, fileName: '' };
    const shortState = (domainId, token) => {
      const state = stateFor(domainId);
      const mark = state.loaded ? 'ok' : '--';
      const dirty = state.dirty ? '*' : '';
      return `${token}:${mark}${dirty}`;
    };

    workspacePill.textContent = [
      shortState('manufacturer', 'M'),
      shortState('products', 'P'),
      shortState('materials', 'T'),
    ].join('  ');

    domainPill.textContent = `Domain: ${activeDomainLabel}`;
    status.textContent = this.model.statusText || '';

    if (newDomainBtn) {
      newDomainBtn.textContent = `New ${activeDomainLabel}`;
      newDomainBtn.disabled = !isSourceDomain;
    }
    if (openDomainBtn) {
      openDomainBtn.textContent = `Open ${activeDomainLabel}`;
      openDomainBtn.disabled = !isSourceDomain;
    }
    if (saveDomainBtn) {
      saveDomainBtn.textContent = `Save ${activeDomainLabel}`;
      saveDomainBtn.disabled = !isSourceDomain;
    }
    if (saveDomainAsBtn) {
      saveDomainAsBtn.textContent = `Save ${activeDomainLabel} As`;
      saveDomainAsBtn.disabled = !isSourceDomain;
    }
    if (downloadExportBtn) {
      downloadExportBtn.disabled = !this.model.canDownloadExport;
    }
  }

  render() {
    this.shadowRoot.innerHTML = `
      <style>${configuratorHeaderStyles}</style>
      <header class="topbar">
        <div class="brand">
          <h1 class="title">Configurator Package Manager</h1>
          <p id="statusText" class="status">Open Manufacturer, Products, and Materials source files to begin.</p>
        </div>
        <div class="actions">
          <span id="workspacePill" class="package-pill">M:-- P:-- T:--</span>
          <span id="domainPill" class="package-pill pill-neutral">Domain: Manufacturer</span>
          <button id="newWorkspaceBtn" class="btn" type="button">New Workspace</button>
          <button id="newDomainBtn" class="btn" type="button">New Manufacturer</button>
          <button id="openDomainBtn" class="btn" type="button">Open Manufacturer</button>
          <button id="saveDomainBtn" class="btn btn-primary" type="button">Save Manufacturer</button>
          <button id="saveDomainAsBtn" class="btn" type="button">Save Manufacturer As</button>
          <button id="openLegacyBtn" class="btn" type="button">Open Legacy Package</button>
          <button id="generateExportBtn" class="btn" type="button">Generate Export</button>
          <button id="downloadExportBtn" class="btn" type="button" disabled>Download Export</button>
        </div>
      </header>
    `;
  }
}

if (!customElements.get('open-configurator-header')) {
  customElements.define('open-configurator-header', OpenConfiguratorHeaderElement);
}

export { OpenConfiguratorHeaderElement };
